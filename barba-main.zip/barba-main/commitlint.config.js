module.exports = {
  extends: ['ccgls'],
};
