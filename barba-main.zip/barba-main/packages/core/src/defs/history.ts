/**
 * @module typings/history
 */

export type HistoryAction = 'push' | 'replace';
