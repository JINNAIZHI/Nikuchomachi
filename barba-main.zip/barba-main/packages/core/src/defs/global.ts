/**
 * @module typings/core
 */

export interface IGenericObject {
  [key: string]: string;
}
