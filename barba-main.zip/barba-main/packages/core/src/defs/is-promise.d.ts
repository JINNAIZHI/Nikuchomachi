declare module 'is-promise';
