/**
 * @module typings/core
 */

export type IgnoreOption = boolean | string | string[];
