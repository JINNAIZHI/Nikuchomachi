# @barba/core

[![NPM version](https://img.shields.io/npm/v/@barba/core?style=flat-square)](https://www.npmjs.com/package/@barba/core)
[![Dependencies](https://img.shields.io/librariesio/release/npm/@barba/core?style=flat-square)](https://github.com/barbajs/barba/network/dependencies)

> TBD ([GitHub repo](https://github.com/barbajs/barba.js))

## Install

Using npm:

```sh
npm install --save-dev @barba/core
```

or using yarn:

```sh
yarn add @barba/core --dev
```
