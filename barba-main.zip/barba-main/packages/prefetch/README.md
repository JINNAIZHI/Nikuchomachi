# @barba/prefetch

[![NPM version](https://img.shields.io/npm/v/@barba/prefetch?style=flat-square)](https://www.npmjs.com/package/@barba/prefetch)
[![Dependencies](https://img.shields.io/librariesio/release/npm/@barba/prefetch?style=flat-square)](https://github.com/barbajs/barba/network/dependencies)

> TBD ([GitHub repo](https://github.com/barbajs/barba.js))

## Install

Using npm:

```sh
npm install --save-dev @barba/prefetch
```

or using yarn:

```sh
yarn add @barba/prefetch --dev
```
