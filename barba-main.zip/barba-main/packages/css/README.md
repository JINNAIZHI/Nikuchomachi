# @barba/css

[![NPM version](https://img.shields.io/npm/v/@barba/css?style=flat-square)](https://www.npmjs.com/package/@barba/css)
[![Dependencies](https://img.shields.io/librariesio/release/npm/@barba/css?style=flat-square)](https://github.com/barbajs/barba/network/dependencies)

> TBD ([GitHub repo](https://github.com/barbajs/barba.js))

## Install

Using npm:

```sh
npm install --save-dev @barba/css
```

or using yarn:

```sh
yarn add @barba/css --dev
```
