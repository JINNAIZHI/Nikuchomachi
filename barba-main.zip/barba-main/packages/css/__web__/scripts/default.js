console.info('🚀 Barba e2e');

const { barba, barbaCss: css } = window;

barba.use(css);
barba.init({ debug: true });
